create view start_date as
SELECT min(asx."Date") AS date,
       asx.code
FROM asx
GROUP BY asx.code;

alter table start_date
    owner to postgres;

