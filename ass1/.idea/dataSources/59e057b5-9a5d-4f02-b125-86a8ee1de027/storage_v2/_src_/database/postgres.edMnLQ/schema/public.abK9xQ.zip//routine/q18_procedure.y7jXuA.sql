create function q18_procedure() returns trigger
    language plpgsql
as
$$
declare

begin
    raise notice 'update triggered...';
    insert into asxlog values (now(), old."Date", old.Code, old.volume, old.price);
    return new;

end;
$$;

alter function q18_procedure() owner to postgres;

