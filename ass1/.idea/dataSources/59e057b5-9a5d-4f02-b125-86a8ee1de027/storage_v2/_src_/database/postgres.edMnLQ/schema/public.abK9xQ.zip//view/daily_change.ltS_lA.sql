create view daily_change as
SELECT a.code,
       a."Date",
       (a.price - lag(a.price, 1) OVER (PARTITION BY a.code ORDER BY a."Date")) AS change
FROM asx a;

alter table daily_change
    owner to postgres;

