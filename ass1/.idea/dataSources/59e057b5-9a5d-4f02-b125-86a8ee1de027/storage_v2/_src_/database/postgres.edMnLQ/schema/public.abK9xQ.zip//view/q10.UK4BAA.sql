create view q10 as
SELECT c.code,
       c.industry
FROM category c,
     count_industry ci
WHERE (((c.industry)::text = (ci.industry)::text) AND (ci.count = 1));

alter table q10
    owner to postgres;

