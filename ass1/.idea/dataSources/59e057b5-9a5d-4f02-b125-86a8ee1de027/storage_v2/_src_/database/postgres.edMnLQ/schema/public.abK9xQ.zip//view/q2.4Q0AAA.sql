create view q2 as
SELECT e.code
FROM executive e
GROUP BY e.code
HAVING (count(e.code) > 5);

alter table q2
    owner to postgres;

