create view end_price as
SELECT a.price AS endprice,
       a.code
FROM asx a,
     end_date ed
WHERE ((a.code = ed.code) AND (a."Date" = ed.date));

alter table end_price
    owner to postgres;

