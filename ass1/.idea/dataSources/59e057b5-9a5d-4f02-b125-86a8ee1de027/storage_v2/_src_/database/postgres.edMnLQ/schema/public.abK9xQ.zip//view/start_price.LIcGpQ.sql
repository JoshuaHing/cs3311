create view start_price as
SELECT a.price AS startprice,
       a.code
FROM asx a,
     start_date sd
WHERE ((a.code = sd.code) AND (a."Date" = sd.date));

alter table start_price
    owner to postgres;

