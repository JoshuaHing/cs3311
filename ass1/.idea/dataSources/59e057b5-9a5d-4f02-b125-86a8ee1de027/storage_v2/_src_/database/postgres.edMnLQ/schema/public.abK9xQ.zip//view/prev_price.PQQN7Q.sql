create view prev_price as
SELECT a.code,
       a."Date",
       lag(a.price, 1) OVER (PARTITION BY a.code ORDER BY a."Date") AS prev
FROM asx a;

alter table prev_price
    owner to postgres;

