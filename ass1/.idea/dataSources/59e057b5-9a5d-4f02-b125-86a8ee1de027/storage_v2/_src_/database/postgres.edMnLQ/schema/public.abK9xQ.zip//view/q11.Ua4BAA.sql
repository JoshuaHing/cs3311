create view q11 as
SELECT c.sector,
       avg(r.star) AS avgrating
FROM (category c
         JOIN rating r ON ((c.code = r.code)))
GROUP BY c.sector, r.star
ORDER BY r.star DESC, c.sector;

alter table q11
    owner to postgres;

