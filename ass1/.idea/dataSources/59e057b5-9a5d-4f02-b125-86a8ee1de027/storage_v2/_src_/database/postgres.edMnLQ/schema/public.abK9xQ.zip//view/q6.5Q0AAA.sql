create view q6 as
SELECT c.name,
       c.country,
       c.zip
FROM (company c
         JOIN category c2 ON ((c.code = c2.code)))
WHERE (((c2.sector)::text = 'Services'::text) AND ((c.country)::text = 'Australia'::text) AND
       ((c.zip)::text ~ '^2[0-9]{3}$'::text));

alter table q6
    owner to postgres;

