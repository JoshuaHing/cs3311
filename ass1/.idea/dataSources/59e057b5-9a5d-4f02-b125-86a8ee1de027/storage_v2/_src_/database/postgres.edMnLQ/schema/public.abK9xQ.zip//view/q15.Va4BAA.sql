create view q15 as
SELECT a.code,
       min(a.price)                               AS minprice,
       avg(a.price)                               AS avgprice,
       max(a.price)                               AS maxprice,
       min(q7.gain)                               AS mindaygain,
       (sum(q7.gain) / (count(q7.code))::numeric) AS avgdaygain,
       max(q7.gain)                               AS maxdaygain
FROM asx a,
     q7
WHERE (a.code = q7.code)
GROUP BY a.code;

alter table q15
    owner to postgres;

