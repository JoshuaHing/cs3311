create view not_in_aust as
SELECT c.code,
       c.country
FROM company c
WHERE (NOT ((c.country)::text = 'Australia'::text));

alter table not_in_aust
    owner to postgres;

