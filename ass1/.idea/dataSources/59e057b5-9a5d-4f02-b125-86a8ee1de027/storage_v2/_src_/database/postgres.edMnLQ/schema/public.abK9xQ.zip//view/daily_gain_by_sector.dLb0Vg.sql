create view daily_gain_by_sector as
SELECT c.sector,
       q7."Date",
       c.code,
       q7.gain
FROM (q7 q7
         JOIN category c ON ((q7.code = c.code)));

alter table daily_gain_by_sector
    owner to postgres;

