create view q12 as
SELECT executive.person AS name
FROM executive
GROUP BY executive.person
HAVING (count(executive.person) > 1);

alter table q12
    owner to postgres;

