create view q14 as
SELECT DISTINCT a.code,
                sp.startprice                                                      AS beginprice,
                ep.endprice,
                (ep.endprice - sp.startprice)                                      AS change,
                (((ep.endprice - sp.startprice) / sp.startprice) * (100)::numeric) AS gain
FROM asx a,
     start_price sp,
     end_price ep
WHERE ((a.code = sp.code) AND (a.code = ep.code))
ORDER BY (((ep.endprice - sp.startprice) / sp.startprice) * (100)::numeric) DESC, a.code;

alter table q14
    owner to postgres;

