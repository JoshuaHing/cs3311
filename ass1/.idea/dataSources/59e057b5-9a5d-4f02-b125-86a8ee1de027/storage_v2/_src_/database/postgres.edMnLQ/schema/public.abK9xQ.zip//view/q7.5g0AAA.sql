create view q7 as
SELECT a."Date",
       a.code,
       a.volume,
       pp.prev                                  AS prevprice,
       a.price,
       dc.change,
       ((dc.change / pp.prev) * (100)::numeric) AS gain
FROM asx a,
     prev_price pp,
     daily_change dc,
     min_date md
WHERE ((a.code = pp.code) AND (a.code = dc.code) AND (a.code = md.code) AND (a."Date" <> md."Date") AND
       (a."Date" = pp."Date") AND (a."Date" = dc."Date"));

alter table q7
    owner to postgres;

