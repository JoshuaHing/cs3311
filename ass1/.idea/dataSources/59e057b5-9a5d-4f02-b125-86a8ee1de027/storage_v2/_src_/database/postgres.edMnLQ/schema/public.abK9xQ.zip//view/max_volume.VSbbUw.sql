create view max_volume as
SELECT asx."Date",
       max(asx.volume) AS volume
FROM asx
GROUP BY asx."Date";

alter table max_volume
    owner to postgres;

