create view q7_2 as
SELECT a."Date",
       a.code,
       a.volume,
       lag(a.price, 1, NULL::numeric) OVER (PARTITION BY a.code ORDER BY a."Date")                      AS prevprice,
       a.price,
       (a.price - lag(a.price, 1, NULL::numeric) OVER (PARTITION BY a.code ORDER BY a."Date"))          AS change,
       (((a.price - lag(a.price, 1, NULL::numeric) OVER (PARTITION BY a.code ORDER BY a."Date")) /
         lag(a.price, 1, NULL::numeric) OVER (PARTITION BY a.code ORDER BY a."Date")) * (100)::numeric) AS gain
FROM asx a;

alter table q7_2
    owner to postgres;

