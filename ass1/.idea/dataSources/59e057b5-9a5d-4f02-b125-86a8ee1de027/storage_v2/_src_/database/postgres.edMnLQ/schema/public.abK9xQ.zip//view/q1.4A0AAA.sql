create view q1 as
SELECT company.name,
       company.country
FROM company
WHERE (NOT ((company.country)::text = 'Australia'::text));

alter table q1
    owner to postgres;

