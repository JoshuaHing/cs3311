create view q5 as
SELECT e.person AS name
FROM (executive e
         JOIN category c ON ((e.code = c.code)))
WHERE ((c.sector)::text = 'Technology'::text);

alter table q5
    owner to postgres;

