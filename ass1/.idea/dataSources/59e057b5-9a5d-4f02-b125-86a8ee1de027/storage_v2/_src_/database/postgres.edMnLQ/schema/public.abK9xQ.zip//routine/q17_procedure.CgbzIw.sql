create function q17_procedure() returns trigger
    language plpgsql
as
$$
declare
    daily_max float;
    daily_min float;
    curr_gain float;
    company_sector varchar(40);
begin
    select sector into company_sector from category where new.code = code;
    select max_gain into daily_max from daily_maxgain_by_sector dgs1 where company_sector = dgs1.sector and "Date" = dgs1."Date";
    select min_gain into daily_min from daily_mingain_by_sector dgs2 where company_sector = dgs2.sector and "Date" = dgs2."Date";

    -- get the gain of the company in question
    select gain into curr_gain from daily_gain_by_sector where new.code = code and new."Date" = "Date";

    raise notice 'max_gain for sector: % and date % is %', company_sector, new."Date", daily_max;
    raise notice 'curr_gain is %', curr_gain;
    if curr_gain >= daily_max
    then
        update rating set star = 5
        where code = new.code;
        raise notice 'Changing % to 5 star rating...', new.code;
    end if;

    if curr_gain <= daily_min
    then
        update rating set star = 1
        where code = new.code;
        raise notice 'Changing % to 1 star rating...', new.code;
    end if;

    return new;

    -- Now, calculate the gain of the updated entry...?
end;
$$;

alter function q17_procedure() owner to postgres;

