create view q9 as
SELECT category.sector,
       category.industry,
       count(*) AS number
FROM category
GROUP BY category.industry, category.sector
ORDER BY category.sector, category.industry;

alter table q9
    owner to postgres;

