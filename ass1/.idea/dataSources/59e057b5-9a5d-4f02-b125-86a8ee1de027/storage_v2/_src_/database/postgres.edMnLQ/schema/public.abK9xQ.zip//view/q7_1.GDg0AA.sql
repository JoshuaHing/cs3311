create view q7_1 as
SELECT DISTINCT min(asx."Date") AS "Date"
FROM asx;

alter table q7_1
    owner to postgres;

