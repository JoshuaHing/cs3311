create view daily_mingain_by_sector as
SELECT daily_gain_by_sector.sector,
       daily_gain_by_sector."Date",
       min(daily_gain_by_sector.gain) AS min_gain
FROM daily_gain_by_sector
GROUP BY daily_gain_by_sector."Date", daily_gain_by_sector.sector
ORDER BY daily_gain_by_sector.sector, daily_gain_by_sector."Date";

alter table daily_mingain_by_sector
    owner to postgres;

