create view q4 as
SELECT category.sector,
       count(DISTINCT category.industry) AS count
FROM category
GROUP BY category.sector;

alter table q4
    owner to postgres;

