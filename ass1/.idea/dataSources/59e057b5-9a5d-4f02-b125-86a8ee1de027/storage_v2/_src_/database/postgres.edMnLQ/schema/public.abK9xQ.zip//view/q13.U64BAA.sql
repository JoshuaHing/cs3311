create view q13 as
SELECT c1.code,
       c1.name,
       c1.address,
       c1.zip,
       c2.sector
FROM (company c1
         JOIN category c2 ON ((c1.code = c2.code))),
     sect s
WHERE (NOT ((c2.sector)::text IN (SELECT sect.sector
                                  FROM sect)))
GROUP BY c2.sector, c1.code, c1.name, c1.address, c1.zip;

alter table q13
    owner to postgres;

