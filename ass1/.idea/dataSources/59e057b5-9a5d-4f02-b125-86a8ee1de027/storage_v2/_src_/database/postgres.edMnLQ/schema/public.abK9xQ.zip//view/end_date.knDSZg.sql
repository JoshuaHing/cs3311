create view end_date as
SELECT max(asx."Date") AS date,
       asx.code
FROM asx
GROUP BY asx.code;

alter table end_date
    owner to postgres;

