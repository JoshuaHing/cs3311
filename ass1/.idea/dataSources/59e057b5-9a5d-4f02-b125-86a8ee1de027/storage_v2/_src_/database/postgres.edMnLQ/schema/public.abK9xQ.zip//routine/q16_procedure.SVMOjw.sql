create function q16_procedure() returns trigger
    language plpgsql
as
$$
declare
    num_companies int;
begin
    select count(*) into num_companies from executive where person = new.person;
    if num_companies > 1
        then raise exception 'Executive must work for one company only.';
    end if ;
    return new;
end;
$$;

alter function q16_procedure() owner to postgres;

