create view count_industry as
SELECT category.industry,
       count(*) AS count
FROM category
GROUP BY category.industry;

alter table count_industry
    owner to postgres;

