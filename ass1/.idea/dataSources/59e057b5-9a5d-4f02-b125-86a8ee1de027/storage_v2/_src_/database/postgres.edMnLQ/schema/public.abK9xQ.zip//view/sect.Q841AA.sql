create view sect as
SELECT c2.sector
FROM (company c1
         JOIN category c2 ON ((c1.code = c2.code))),
     not_in_aust nia
WHERE ((c1.code = nia.code) AND ((c1.country)::text = (nia.country)::text))
GROUP BY c2.sector;

alter table sect
    owner to postgres;

