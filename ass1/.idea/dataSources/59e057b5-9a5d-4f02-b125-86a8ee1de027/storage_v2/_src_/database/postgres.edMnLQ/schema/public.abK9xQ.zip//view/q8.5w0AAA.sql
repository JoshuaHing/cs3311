create view q8 as
SELECT q7_2."Date",
       q7_2.code,
       q7_2.volume,
       q7_2.prevprice,
       q7_2.price,
       q7_2.change,
       q7_2.gain
FROM q7_2
WHERE (q7_2."Date" <> (SELECT q7_1."Date"
                       FROM q7_1));

alter table q8
    owner to postgres;

