create view q8 as
SELECT a."Date",
       a.code,
       a.volume
FROM asx a,
     max_volume m
WHERE ((a."Date" = m."Date") AND (a.volume = m.volume))
GROUP BY a."Date", a.code;

alter table q8
    owner to postgres;

