create view min_date as
SELECT asx.code,
       min(asx."Date") AS "Date"
FROM asx
GROUP BY asx.code;

alter table min_date
    owner to postgres;

