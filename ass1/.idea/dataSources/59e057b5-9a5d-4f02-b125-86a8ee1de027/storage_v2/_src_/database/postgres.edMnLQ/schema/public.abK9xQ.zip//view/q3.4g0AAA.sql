create view q3 as
SELECT c.name
FROM (company c
         JOIN category c2 ON ((c.code = c2.code)))
WHERE ((c2.sector)::text = 'Technology'::text);

alter table q3
    owner to postgres;

